public class MedicalRecords {
    private String diagnoses;
    private String prescribedMedications;
    private String treatmentHistory;
    private String Schedule;

    public MedicalRecords(){

    }

    public MedicalRecords(String )
}
